app.get('/api/authors', (req, res) => {
  try {
    const authors = db.prepare(`
      SELECT DISTINCT author FROM (
        SELECT author FROM fawaid WHERE author IS NOT NULL AND author != ''
        UNION
        SELECT author FROM books WHERE author IS NOT NULL AND author != ''
        UNION
        SELECT author FROM shuruhat WHERE author IS NOT NULL AND author != ''
      ) ORDER BY author ASC
    `).all();
    res.json(authors.map((a: any) => a.author));
  } catch (error) {
    res.status(500).json({ error: 'DB Error' });
  }
});
